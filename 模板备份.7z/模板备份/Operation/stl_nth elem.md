
+ nth_element(first,nth,last)
+ first，last 第一个和最后一个元素位置
+ nth:要定位的第n个元素
+ nth_element会将第n_th 元素放到它该放的位置上，左边元素都小于它，右边元素都大于它
期望复杂度o(n)
+ nth_element(a,a+6,a+10);
